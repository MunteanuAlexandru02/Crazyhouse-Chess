#ifndef PLAYSIDE_H
#define PLAYSIDE_H

enum PlaySide { BLACK = 0, WHITE = 1, NONE = 2 };

#endif // !PLAYSIDE_H
